package ac.th.itsci.durable.entity;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class VerifyDurable {

	@EmbeddedId
	private VerifyDurableID pk = new VerifyDurableID();

	private String Save_date;
	private String Durable_status;
	private String note;

	public VerifyDurable() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getSave_date() {
		return Save_date;
	}

	public void setSave_date(String save_date) {
		Save_date = save_date;
	}

	public String getDurable_status() {
		return Durable_status;
	}

	public void setDurable_status(String durable_status) {
		Durable_status = durable_status;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public VerifyDurableID getPk() {
		return pk;
	}

	public void setPk(VerifyDurableID pk) {
		this.pk = pk;
	}
	

}
