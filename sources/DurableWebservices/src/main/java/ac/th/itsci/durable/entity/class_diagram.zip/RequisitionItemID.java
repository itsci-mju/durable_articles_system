package ac.th.itsci.durable.entity;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;

@Embeddable
public class RequisitionItemID implements Serializable {

	@ManyToOne
	private Document document;
	@ManyToOne
	private Item item;
	@ManyToOne
	private Personnel personnel;
	@ManyToOne
	private RequisitionDocument requisition;

	public RequisitionItemID() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RequisitionItemID(Document document, Item item, Personnel personnel) {
		super();
		this.document = document;
		this.item = item;
		this.personnel = personnel;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Personnel getPersonnel() {
		return personnel;
	}

	public void setPersonnel(Personnel personnel) {
		this.personnel = personnel;
	}

	public RequisitionDocument getRequisition() {
		return requisition;
	}

	public void setRequisition(RequisitionDocument requisition) {
		this.requisition = requisition;
	}

	
	
}
