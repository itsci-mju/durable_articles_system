package ac.th.itsci.durable.entity;

import javax.persistence.*;


@Entity
@Table(name="committee")
public class Committee {
	
	@EmbeddedId
	private CommitteeID committee = new CommitteeID();

	public Committee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Committee(CommitteeID committee) {
		super();
		this.committee = committee;
	}

	public CommitteeID getCommittee() {
		return committee;
	}

	public void setCommittee(CommitteeID committee) {
		this.committee = committee;
	}
	
	
}
